#pragma once
#include <stdexcept>
#include <iostream>

class MatrixIsDegenerateError : public std::runtime_error {
 public:
  MatrixIsDegenerateError() : std::runtime_error("MatrixIsDegenerateError") {
  }
};

class MatrixOutOfRange : public std::out_of_range {
 public:
  MatrixOutOfRange() : std::out_of_range("MatrixOutOfRange") {
  }
};

template <typename T, size_t Rows, size_t Columns>
class Matrix {
 public:
  T data[Rows][Columns];

  size_t RowsNumber() const {
    return Rows;
  }

  size_t ColumnsNumber() const {
    return Columns;
  }

  T& operator()(size_t row, size_t col) {
    return data[row][col];
  }

  const T& operator()(size_t row, size_t col) const {
    return data[row][col];
  }

  T& At(size_t row, size_t col) {
    if (row >= Rows || col >= Columns) {
      throw MatrixOutOfRange();
    }
    return data[row][col];
  }

  const T& At(size_t row, size_t col) const {
    if (row >= Rows || col >= Columns) {
      throw MatrixOutOfRange();
    }
    return data[row][col];
  }

  Matrix<T, Columns, Rows> GetTransposed() const {
    Matrix<T, Columns, Rows> result;
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        result(j, i) = data[i][j];
      }
    }
    return result;
  }

  Matrix<T, Rows, Columns>& operator+=(const Matrix<T, Rows, Columns>& other) {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        data[i][j] += other.data[i][j];
      }
    }
    return *this;
  }

  Matrix<T, Rows, Columns> operator+(const Matrix<T, Rows, Columns>& other) const {
    Matrix<T, Rows, Columns> result = *this;
    result += other;
    return result;
  }

  Matrix<T, Rows, Columns>& operator-=(const Matrix<T, Rows, Columns>& other) {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        data[i][j] -= other.data[i][j];
      }
    }
    return *this;
  }

  Matrix<T, Rows, Columns> operator-(const Matrix<T, Rows, Columns>& other) const {
    Matrix<T, Rows, Columns> result = *this;
    result -= other;
    return result;
  }

  template <size_t OtherColumns>
  Matrix<T, Rows, OtherColumns> operator*(const Matrix<T, Columns, OtherColumns>& other) const {
    Matrix<T, Rows, OtherColumns> result{};
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < OtherColumns; ++j) {
        for (size_t k = 0; k < Columns; ++k) {
          result(i, j) += data[i][k] * other.data[k][j];
        }
      }
    }
    return result;
  }

  Matrix<T, Rows, Columns>& operator*=(const T& scalar) {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        data[i][j] *= scalar;
      }
    }
    return *this;
  }

  Matrix<T, Rows, Columns> operator*(const T& scalar) const {
    Matrix<T, Rows, Columns> result = *this;
    result *= scalar;
    return result;
  }

  Matrix<T, Rows, Columns>& operator/=(const T& scalar) {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        data[i][j] /= scalar;
      }
    }
    return *this;
  }

  Matrix<T, Rows, Columns> operator/(const T& scalar) const {
    Matrix<T, Rows, Columns> result = *this;
    result /= scalar;
    return result;
  }

  bool operator==(const Matrix<T, Rows, Columns>& other) const {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        if (data[i][j] != other.data[i][j]) {
          return false;
        }
      }
    }
    return true;
  }

  bool operator!=(const Matrix<T, Rows, Columns>& other) const {
    return !(*this == other);
  }

  friend std::ostream& operator<<(std::ostream& out, const Matrix<T, Rows, Columns>& matrix) {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        out << matrix.data[i][j];
        if (j < Columns - 1) {
          out << ' ';
        }
      }
      if (i < Rows - 1) {
        out << '\n';
      }
    }
    return out;
  }

  friend std::istream& operator>>(std::istream& in, Matrix<T, Rows, Columns>& matrix) {
    for (size_t i = 0; i < Rows; ++i) {
      for (size_t j = 0; j < Columns; ++j) {
        in >> matrix.data[i][j];
      }
    }
    return in;
  }
};

#endif  // MATRIX_H