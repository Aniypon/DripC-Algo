#ifndef ARRAY_H
#define ARRAY_H

#include <stdexcept>
#include <cstddef>
#include <algorithm>

class ArrayOutOfRange : public std::out_of_range {
 public:
  ArrayOutOfRange() : std::out_of_range("Array index out of range") {}
};

template <typename T, size_t N>
class Array {
 public:
  T elements[N];

  T& operator[](size_t index) {
    return elements[index];
  }

  const T& operator[](size_t index) const {
    return elements[index];
  }

  T& At(size_t index) {
    if (index >= N) {
      throw ArrayOutOfRange();
    }
    return elements[index];
  }

  const T& At(size_t index) const {
    if (index >= N) {
      throw ArrayOutOfRange();
    }
    return elements[index];
  }

  T& First() {
    return elements[0];
  }

  const T& First() const {
    return elements[0];
  }

  T& Last() {
    return elements[N - 1];
  }

  const T& Last() const {
    return elements[N - 1];
  }

  T* Data() {
    return elements;
  }

  const T* Data() const {
    return elements;
  }

  size_t Size() const {
    return N;
  }

  bool IsEmpty() const {
    return N == 0;
  }

  void Fill(const T& value) {
    for (size_t i = 0; i < N; ++i) {
      elements[i] = value;
    }
  }

  void Swap(Array<T, N>& other) {
    for (size_t i = 0; i < N; ++i) {
      std::swap(elements[i], other.elements[i]);
    }
  }
};

#endif  // ARRAY_H